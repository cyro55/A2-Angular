import { Component, OnInit } from '@angular/core';
import { CyroService } from '../cyro.service';

@Component({
  selector: 'app-cyro-task',
  templateUrl: './cyro-task.component.html',
  styleUrls: ['./cyro-task.component.css']
})
export class CyroTaskComponent implements OnInit {

  constructor(private CyroService: CyroService) { }

  task: string ='';
  tarefas = [];


  ngOnInit() {
    this.tarefas = this.CyroService.tarefas;
  }

  cadastrarTarefa() {
    this.CyroService.tarefas.push(this.task);
    this.tarefas = this.CyroService.tarefas;
  }

  deletar(index: number) {
    this.CyroService.tarefas.splice(index, 1);
    this.tarefas = this.CyroService.tarefas;
  }



}
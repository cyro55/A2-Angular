import { Component, OnInit } from '@angular/core';
import { CyroService } from '../cyro.service';

@Component({
  selector: 'app-cyro-home',
  templateUrl: './cyro-home.component.html',
  styleUrls: ['./cyro-home.component.css']
})
export class CyroHomeComponent implements OnInit {

  constructor(private CyroService: CyroService) { }

  numTarefas = 0;

  ngOnInit() {
    this.numTarefas = this.CyroService.tarefas.length;
  }

}